[![Build Status](https://travis-ci.org/JayVora-SerpentCS/hotelmgmt_v8.svg?branch=8.0)](https://travis-ci.org/JayVora-SerpentCS/hotelmgmt_v8)
[![Build Status](https://travis-ci.org/JayVora-SerpentCS/hotelmgmt_v8.svg?branch=master)](https://travis-ci.org/JayVora-SerpentCS/hotelmgmt_v8)

hotelmgmt_v8
============

Hotel Management System V8
